"""See what has been recorded: counts sessions by cheat type and player, and
writes data/sessions.csv (one line per session).

    python processing/sessions.py

sessions.csv is rebuilt from the session folders each time rather than added to
after every session, so two people recording into the same Drive folder can
never overwrite each other's lines. Don't edit it by hand -- re-run this instead.
"""
import csv
from collections import Counter

from common import DATA_DIR, list_sessions

COLUMNS = ["folder", "recorded_at", "player", "cheat", "label", "aim_cheat_level", "wallhack_level",
           "duration_s", "targets_appeared", "targets_hit", "accuracy_pct", "median_time_to_kill_ms"]


def main():
    sessions = list_sessions()
    if not sessions:
        raise SystemExit(f"No sessions found in {DATA_DIR}")

    # sessions per cheat type, split by player
    players = sorted({s["player"] for s in sessions})
    counts = Counter((s["cheat"], s["player"]) for s in sessions)
    cheats = sorted({s["cheat"] for s in sessions})
    width = max(len(c) for c in cheats + ["cheat"])
    print(f"{len(sessions)} sessions in {DATA_DIR}\n")
    print(f"{'cheat':<{width}}  " + "  ".join(f"{p:>10}" for p in players) + "       total")
    for cheat in cheats:
        per = [counts[(cheat, p)] for p in players]
        print(f"{cheat:<{width}}  " + "  ".join(f"{n:>10}" for n in per) + f"  {sum(per):>10}")

    out = DATA_DIR / "sessions.csv"
    with open(out, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(COLUMNS)
        for s in sessions:
            r = s["results"]
            level = {k: v["level"] for k, v in s["strength"].items()}
            writer.writerow([s["folder"], s["folder"][:19].replace("_", " "), s["player"], s["cheat"],
                             s["label"], level.get("aim_cheat", ""), level.get("wallhack", ""),
                             r["duration_s"], r["targets_appeared"], r["targets_hit"],
                             r["accuracy_pct"], r["median_time_to_kill_ms"]])
    print(f"\nWrote {out}")


if __name__ == "__main__":
    main()
