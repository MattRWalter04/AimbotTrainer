"""Re-create each session from its replay/ data and save it as an MP4 -- the input
for the video model.

The session is replayed with Tim's own code: targets are created at their logged
spawn frame and grown/shrunk by Tim's Target.update() every frame, exactly as in
the game, then drawn with Tim's draw() plus the crosshair. The video differs from
what the player saw in two ways:
  * no top bar (it shows the cheat name and score, which would leak the answer)
  * no wallhack overlay (real recordings/replays never show a cheater's overlay,
    so the video model has to spot wallhacks from behavior alone)
Videos are sampled at a fixed frame rate, like a real screen recording.

    python processing/render_video.py                 # 60 and 30 fps, 640x480
    python processing/render_video.py --fps 30 --scale 0.5
"""
import argparse
import os
from collections import defaultdict
from multiprocessing import Pool

os.environ.setdefault("SDL_VIDEODRIVER", "dummy")  # draw off-screen, no window

from common import VIDEO_DIR, list_sessions, read_csv


def replay_frames(folder):
    """Yields (time_s, crosshair, visible Tim Targets) for every logged frame."""
    import game
    tim = game.tim

    frames = read_csv(folder, "replay/frames.csv")
    spawning = defaultdict(list)                     # frame -> targets that appear on it
    for tg in read_csv(folder, "replay/targets.csv"):
        if tg["spawn_frame"] is not None:
            spawning[tg["spawn_frame"]].append(tg)

    active = {}                                      # target_id -> (Tim Target, end_frame)
    for row in frames:
        i = row["frame"]
        for tg in spawning[i]:
            active[tg["target_id"]] = (tim.Target(tg["x"], tg["y"]), tg["end_frame"])
        for target_id, (target, end_frame) in list(active.items()):
            target.update()                          # Tim's grow/shrink, same as the game
            if end_frame is not None and i >= end_frame:
                del active[target_id]                # hit or expired on this frame
        yield row["time_s"], (row["crosshair_x"], row["crosshair_y"]), [t for t, _ in active.values()]


def render(job):
    folder, fps, scale, quality = job
    import imageio.v2 as imageio
    import pygame

    import game
    tim = game.tim

    out = VIDEO_DIR / f"{fps}fps" / f"{folder}.mp4"
    if out.exists():
        return f"skip  {out.parent.name}/{out.name}"
    out.parent.mkdir(parents=True, exist_ok=True)

    full = pygame.Surface((tim.WIDTH, tim.HEIGHT))
    size = (round(tim.WIDTH * scale) // 8 * 8, round(tim.HEIGHT * scale) // 8 * 8)
    tmp = out.with_suffix(".part.mp4")
    writer = imageio.get_writer(tmp, fps=fps, codec="libx264", quality=quality,
                                macro_block_size=8, ffmpeg_log_level="error")

    def emit(crosshair, targets):
        tim.draw(full, targets)
        game.draw_crosshair(full, crosshair)
        frame = pygame.transform.smoothscale(full, size) if size != full.get_size() else full
        writer.append_data(pygame.surfarray.array3d(frame).swapaxes(0, 1))

    # Video frame k shows the game as it was at time k / fps (the latest logged frame).
    k = 0
    state = (tim.WIDTH / 2, (tim.HEIGHT + game.PLAY_TOP) / 2), []   # before the first frame
    for time_s, crosshair, targets in replay_frames(folder):
        while k / fps < time_s:
            emit(*state)
            k += 1
        state = crosshair, targets
    emit(*state)
    writer.close()
    tmp.replace(out)
    return f"done  {out.parent.name}/{out.name}"


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--fps", type=int, nargs="+", default=[60, 30])
    p.add_argument("--scale", type=float, default=0.8, help="0.8 = 640x480")
    p.add_argument("--quality", type=float, default=7, help="H.264 quality 0-10 (lower = more compression)")
    p.add_argument("--workers", type=int, default=max(1, (os.cpu_count() or 2) - 1))
    args = p.parse_args()

    jobs = [(s["folder"], fps, args.scale, args.quality) for s in list_sessions() for fps in args.fps]
    with Pool(args.workers) as pool:
        for i, msg in enumerate(pool.imap_unordered(render, jobs), 1):
            print(f"[{i}/{len(jobs)}] {msg}")


if __name__ == "__main__":
    main()
