"""Create the single train/val/test split shared by every model.

Splits are by *session* (never by window) and stratified by cheat type, so every
cheat type appears in the test set and no session leaks across splits.

    python processing/make_splits.py            # refuses to overwrite an existing split
    python processing/make_splits.py --force    # re-split (do this only before any results!)
"""
import argparse
import json
import random
from collections import Counter

from common import SPLITS_FILE, list_sessions


def split_group(ids, rng, val_frac, test_frac):
    ids = sorted(ids)
    rng.shuffle(ids)
    n = len(ids)
    n_test = max(1, round(n * test_frac)) if n >= 2 else 0
    n_val = max(1, round(n * val_frac)) if n >= 3 else 0
    return ids[n_test + n_val:], ids[n_test:n_test + n_val], ids[:n_test]


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--val", type=float, default=0.2)
    p.add_argument("--test", type=float, default=0.2)
    p.add_argument("--seed", type=int, default=0)
    p.add_argument("--force", action="store_true")
    args = p.parse_args()

    if SPLITS_FILE.exists() and not args.force:
        raise SystemExit(f"{SPLITS_FILE.name} already exists -- pass --force to re-split.")

    sessions = list_sessions()
    rng = random.Random(args.seed)
    splits = {"train": [], "val": [], "test": []}
    cheats = sorted({s["cheat"] for s in sessions})
    for cheat in cheats:
        ids = [s["folder"] for s in sessions if s["cheat"] == cheat]
        for name, part in zip(("train", "val", "test"), split_group(ids, rng, args.val, args.test)):
            splits[name] += part

    keys = ("player", "cheat", "label", "duration")
    info = {s["folder"]: {k: s[k] for k in keys} for s in sessions}
    SPLITS_FILE.write_text(json.dumps({"seed": args.seed, **splits, "sessions": info}, indent=2))

    print(f"{'cheat':<22} {'train':>5} {'val':>5} {'test':>5}")
    counts = {name: Counter(info[i]["cheat"] for i in ids) for name, ids in splits.items()}
    for cheat in cheats:
        print(f"{cheat:<22} {counts['train'][cheat]:>5} {counts['val'][cheat]:>5} {counts['test'][cheat]:>5}")
    print(f"Saved -> {SPLITS_FILE}")


if __name__ == "__main__":
    main()
