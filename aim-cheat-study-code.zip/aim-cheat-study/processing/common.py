"""Shared loading code for the processing scripts.

Each session lives in its own folder in data/ (layout: see DATA_FORMAT.md).
"""
import csv
import json
import sys
from pathlib import Path

sys.dont_write_bytecode = True  # no __pycache__ folders syncing between computers via Drive

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))   # lets the scripts here import game.py from the project folder

DATA_DIR = ROOT / "data"
VIDEO_DIR = ROOT / "videos"
SPLITS_FILE = DATA_DIR / "splits.json"


def list_sessions():
    """One dict per recorded session (from each folder's summary.json), oldest first."""
    sessions = []
    for summary_path in sorted(DATA_DIR.glob("*/summary.json")):
        summary = json.loads(summary_path.read_text())
        s = summary["session"]
        sessions.append({
            "folder": s["folder"],
            "player": s["player"],
            "cheat": s["cheat"],         # e.g. 'clean', 'soft_aim', 'strong_aim+wallhack', 'snap'
            "label": s["label"],         # 0 = clean, 1 = cheating
            "duration": summary["results"]["duration_s"],
            "strength": summary["cheat_strength"],   # {} for clean; see DATA_FORMAT.md
            "settings": summary["settings"],
            "results": summary["results"],
        })
    return sessions


def read_csv(folder, name):
    """Load a session CSV (e.g. 'frames.csv', 'targets.csv', 'replay/frames.csv') as a list
    of dicts. Numbers become int/float; blanks become None; text stays text."""
    rows = []
    with open(DATA_DIR / folder / name, newline="") as f:
        for row in csv.DictReader(f):
            rows.append({k: _parse(v) for k, v in row.items()})
    return rows


def _parse(v):
    if v == "":
        return None
    for cast in (int, float):
        try:
            return cast(v)
        except ValueError:
            pass
    return v
